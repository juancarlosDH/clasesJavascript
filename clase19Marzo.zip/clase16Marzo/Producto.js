module.exports = function (nombre, codigo, precio, stock) {
    this.nombre = nombre;
    this.codigo = codigo;
    this.precio = precio;
    this.stock = stock;
}