const Usuario = require('./Usuario');
const fs = require('fs');

//ahora si instacio al usuario
let usuario = new Usuario('Maite', 'maite@pablo.com', 'maite');

//obtengo los usuarios de mi json
const listaUsuariosJson = fs.readFileSync('usuarios.json', 'utf8');

//por defecto voy a tener el array de usuario vacio
let usuariosArray = [];

let encontrado = false;

//si el archivo está vacio no lo convierto y genero un array de usuarios vacio
if (listaUsuariosJson.length == 0) {
    //aqui si meto al nuevo usuario 
    usuariosArray.push(usuario);
} else {
    //convierto el json en JS.
    usuariosArray = JSON.parse(listaUsuariosJson);

    //debo verificar si el email ya está registrado.
    for(let i = 0; i < usuariosArray.length && !encontrado; i++) {
        let usuarioEnArray = usuariosArray[i];
        encontrado = usuario.email == usuarioEnArray.email;
        if (encontrado) {
            console.log('el email ya está registrado.');
        }
    }

    usuariosArray.push(usuario);
}

if (encontrado == false) {
    //convierto o transformo a json el array de usuarios
    const usuariosJsonAGuardar = JSON.stringify(usuariosArray, null, ' ');

    //escribo el archivo completo
    fs.writeFileSync('usuarios.json', usuariosJsonAGuardar);
    console.log('te has registrado en nuestra aplicacion');
}
