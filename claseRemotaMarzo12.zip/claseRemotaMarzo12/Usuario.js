function Usuario(nombre, email, passwd) {
    this.nombre = nombre;
    this.email = email;
    this.passwd = passwd;
}

module.exports = Usuario;